<style>
    .centrar{
        justify-content: center;
        align-items: center;
        margin-left: 100px auto;
    }
</style>