<footer class="bg-body-tertiary text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2020 Copyright:
    <a class="text-body" href="https://mdbootstrap.com/">MDBootstrap.com</a>
  </div>
  <!-- Copyright -->
</footer>

<style>
    .theme-switch-wrapper {
    position: fixed;
    bottom: 80px; /* Subido un poco para no chocar con el footer */
    right: 20px;
    z-index: 1000;
    display: flex;
    align-items: center;
    background-color: #2c2c2c;
    padding: 6px;
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0,0,0,0.3);
}

</style><?php /**PATH C:\Users\User\Documents\Proyectos\Proyectos\Laravel\ejemploapp\resources\views/components/basicFooter.blade.php ENDPATH**/ ?>