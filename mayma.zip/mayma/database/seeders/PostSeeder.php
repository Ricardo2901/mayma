<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Post;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        /*
        $post = new Post();

        $post -> title = 'Title 1';
        $post -> body = 'Body 1';
        $post -> asunto = 'Asunto 1';
        $post -> published_at = now();

        $post -> save();

        */
        //User::factory(10)->create();

        Post::factory(100)->create();
    }
}
